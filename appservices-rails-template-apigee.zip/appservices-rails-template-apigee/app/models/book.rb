#This is a basic usergrid based model.
#You need only to inherit from Usergrid::Ironhorse::Base!
#All the functionality for saving will be encapsulated in this module.
class Book < Usergrid::Ironhorse::Base
  
end
