# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
RailsExample::Application.config.secret_token = '1daa79b51390de644345bb9e005b56f44339cda853bd9bd249b46d60e84f995e7a65d4c098f2d37d14c9696f066aa9c08feaaa3ca4ccdb26313d1c7fc10d6d1f'
